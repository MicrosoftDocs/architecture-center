---
title: "Fusion: What is monitoring & enforcement in relation to cloud governance"
description: Explanation of the concept monitoring & enforcement in relation to cloud governance
author: BrianBlanchard
ms.date: 10/10/2018
---

# Fusion: What is monitoring & enforcement in relation to cloud governance?

Coming soon